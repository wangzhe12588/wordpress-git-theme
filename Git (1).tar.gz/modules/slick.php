<div class="slick">
	<?php
if (git_get_option('git_slick1img_b')) { ?><div><a href="<?php
    echo git_get_option('git_slick1url_b'); ?>"><img width="855px" height="300px" src="<?php
    echo git_get_option('git_slick1img_b'); ?>" alt="<?php
    echo git_get_option('git_slick1title_b'); ?>"><span><?php
    echo git_get_option('git_slick1title_b'); ?></span></a></div><?php
} ?>
	<?php
if (git_get_option('git_slick2img_b')) { ?><div><a href="<?php
    echo git_get_option('git_slick2url_b'); ?>"><img width="855px" height="300px" src="<?php
    echo git_get_option('git_slick2img_b'); ?>" alt="<?php
    echo git_get_option('git_slick2title_b'); ?>"><span><?php
    echo git_get_option('git_slick2title_b'); ?></span></a></div><?php
} ?>
	<?php
if (git_get_option('git_slick3img_b')) { ?><div><a href="<?php
    echo git_get_option('git_slick3url_b'); ?>"><img width="855px" height="300px" src="<?php
    echo git_get_option('git_slick3img_b'); ?>" alt="<?php
    echo git_get_option('git_slick3title_b'); ?>"><span><?php
    echo git_get_option('git_slick3title_b'); ?></span></a></div><?php
} ?>
	<?php
if (git_get_option('git_slick4img_b')) { ?><div><a href="<?php
    echo git_get_option('git_slick4url_b'); ?>"><img width="855px" height="300px" src="<?php
    echo git_get_option('git_slick4img_b'); ?>" alt="<?php
    echo git_get_option('git_slick4title_b'); ?>"><span><?php
    echo git_get_option('git_slick4title_b'); ?></span></a></div><?php
} ?>
	<?php
if (git_get_option('git_slick5img_b')) { ?><div><a href="<?php
    echo git_get_option('git_slick5url_b'); ?>"><img width="855px" height="300px" src="<?php
    echo git_get_option('git_slick5img_b'); ?>" alt="<?php
    echo git_get_option('git_slick5title_b'); ?>"><span><?php
    echo git_get_option('git_slick5title_b'); ?></span></a></div><?php
} ?>
	<?php
if (git_get_option('git_slick6img_b')) { ?><div><a href="<?php
    echo git_get_option('git_slick6url_b'); ?>"><img width="855px" height="300px" src="<?php
    echo git_get_option('git_slick6img_b'); ?>" alt="<?php
    echo git_get_option('git_slick6title_b'); ?>"><span><?php
    echo git_get_option('git_slick6title_b'); ?></span></a></div><?php
} ?>
</div>